package org.dbp.personal.reformas.repository;

import java.math.BigDecimal;

record OpcionPartidaPresupuestaria(
        Long id,
        String descripcion,
        BigDecimal unidades,
        BigDecimal precioUnidad,
        BigDecimal tiempoEstimadoDias,
        String contratista,
        String observaciones
) {
}
public interface OpcionPartidaPresupuestariaRepository {
}
