package org.dbp.personal.reformas.enums;

public enum TipoEntidad {
    CASA,
    COCHE,
    COMPRA_VIVIENDA,
    COMPRA_COCHE,
    PARCELA
}
