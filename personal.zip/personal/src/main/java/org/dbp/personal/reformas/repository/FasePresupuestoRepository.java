package org.dbp.personal.reformas.repository;

import jakarta.persistence.*;

import java.time.LocalDate;
import java.util.List;

record FasePresupuesto(
        @Id
        @GeneratedValue(strategy = GenerationType.IDENTITY)
        Long id,
        String descripcion,
        String fase,
        String responsable,
        String observaciones,
        LocalDate fechaInicio,
        LocalDate fechaFin,
        Integer orden,
        @ManyToOne
        @JoinColumn(name = "presupuesto_id")
        Presupuesto presupuesto,
        @OneToMany(mappedBy = "fase_id", cascade = CascadeType.ALL)
        List<LineaPresupuesto> lineas
) {
}
public interface FasePresupuestoRepository {
}
