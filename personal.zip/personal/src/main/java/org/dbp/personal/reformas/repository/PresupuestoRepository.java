package org.dbp.personal.reformas.repository;

import jakarta.persistence.*;

import java.time.LocalDate;
import java.util.List;

record Presupuesto(
        @Id
        @GeneratedValue(strategy = GenerationType.IDENTITY)
        Long id
        , String descripcion
        , LocalDate fechaInicio
        , LocalDate fechaFin
        , String etiqeuta
        ,@OneToMany(mappedBy = "presupuesto_id", cascade = CascadeType.ALL)
         List<FasePresupuesto> fases
        ){}
public interface PresupuestoRepository {
}
