package org.dbp.personal.reformas.repository;

import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import org.dbp.personal.reformas.enums.TipoEntidad;

record EntidadPresupuesto(
        @Id
        @GeneratedValue(strategy = GenerationType.IDENTITY)
        Long id,
        String descripcion,
        TipoEntidad tipo,
        String responsable,
        String observaciones
) {
}
public interface EntidadPresupuestoRepository {
}
