package org.dbp.personal.reformas.repository;

/*
Partida	Unidades	importe	ejecutar		fase	opcional	Sustituir	Contratista	Observaciones
 */

import jakarta.persistence.*;

import java.math.BigDecimal;

record LineaPresupuesto(
        @Id
        @GeneratedValue(strategy = GenerationType.IDENTITY)
        Long id,
        String partida,
        String zona,
        boolean opcional,
        String observaciones,
        @ManyToOne
        @JoinColumn(name = "fase_id")
        FasePresupuesto fase
) {
}
public interface lineaPresupuestoRepository {
}
